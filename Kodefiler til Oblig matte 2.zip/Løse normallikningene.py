import numpy as np

#Definerer A og Y matrisene ved å sette inn verdiene for konsentrasjon og absorbans
A = np.array([[0.002, 1], 
             [0.004, 1], 
             [0.006, 1],
             [0.008, 1], 
             [0.010, 1],
             [0.012, 1],
             [0.014, 1],
             [0.016, 1],
             [0.018, 1],
             [0.020, 1],
             [0.022, 1],
             [0.024, 1]])

Y = ([[0.0953],
     [0.2008],
     [0.2883],
     [0.3917],
     [0.4807],
     [0.5586],
     [0.6688],
     [0.7656],
     [0.8433],
     [0.9481],
     [1.0291],
     [1.1331],])
     
# Regner ut A^T*A og A^T*Y
ATA = np.dot(A.T, A)
ATy = np.dot(A.T, Y)

# Løser for V, for å finne beta_1 og beta_0
V = np.linalg.solve(ATA, ATy)

print(f"V(beta_1, beta_0) er:{V}")