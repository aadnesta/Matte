import numpy as np 
import matplotlib.pyplot as plt 
from scipy import stats

#Tar inn verdiene for konsentrasjon og absorpsjon
konsentrasjon, absorpsjon = np.loadtxt('Verdier.txt', unpack=True, dtype=float, usecols=(2,3),
delimiter=None)

#Plotter enekeltpunkter, konsentrasjon vs. absorpsjon
plt.figure(figsize=(5,4), dpi=150) 
plt.scatter(konsentrasjon, absorpsjon, label="Enkeltpunkter") 

#Gjør regresjon med stats.linregress-funskjonen og plotter grafen 
slope, intercept, r_value, p_value, std_err = stats.linregress(konsentrasjon, absorpsjon) 
plt.plot(konsentrasjon, konsentrasjon*slope + intercept, ls='--', color='k', label="stats.linregress") 

#Plotter Absorpsjonsfunksjonen med beta-verdiene som jeg fikk ved å løse normallikningene 
beta_1 = 46.7
beta_0 = 0.00985

def Absorbans(c):
    return beta_1 * c + beta_0

c_verdier = np.linspace(0, 0.025, 100)
A_verdier = Absorbans(c_verdier)

plt.plot(c_verdier, A_verdier, color="r", ls ="--", alpha=0.5, label="Normallikningene")

plt.grid() 
plt.xlabel("Konsentrasjon [mol/L]") 
plt.ylabel("Absorpsjon") 
plt.xlim(0,0.025)
plt.legend()
plt.savefig("Plot Oblig")
plt.show()